// =====================================================
// CARTRACK PRO — Comprehensive Global JavaScript Library
// =====================================================

/* ── Vehicle Catalog (Cars & Motorcycles) ── */
const VEHICLES = [
  // ── CARS ──
  {
    id: 'car-yaris',
    type: 'car',
    name: 'Toyota Yaris ATIV Sport',
    category: 'economy',
    categoryName: 'Economy Sedan',
    year: 2024,
    price: 890,
    deposit: 5000,
    image: 'images/car-economy.svg',
    fuel: 'เบนซิน (Gasoline 95)',
    transmission: 'Auto (CVT)',
    seats: 5,
    engine: '1.2L 4-Cyl Dual VVT-iE',
    features: ['GPS Tracker', 'Keyless Entry', 'Dashcam HD', 'Bluetooth / CarPlay', 'Eco Mode'],
    badge: 'ประหยัดยอดนิยม 🌟',
    badgeType: 'success',
    rating: 4.9,
    trips: 342,
    available: true
  },
  {
    id: 'car-civic',
    type: 'car',
    name: 'Honda Civic RS Turbo',
    category: 'sedan',
    categoryName: 'Sport Sedan',
    year: 2024,
    price: 1450,
    deposit: 7000,
    image: 'images/car-sedan.svg',
    fuel: 'เบนซิน (Gasoline 95)',
    transmission: 'Auto (CVT with Paddle Shift)',
    seats: 5,
    engine: '1.5L VTEC Turbo 178 HP',
    features: ['Honda SENSING', 'Wireless Charger', 'Adaptive Cruise', 'Sunroof', 'Digital Cockpit'],
    badge: 'ขับสนุกเร้าใจ 🔥',
    badgeType: 'warning',
    rating: 4.95,
    trips: 218,
    available: true
  },
  {
    id: 'car-fortuner',
    type: 'car',
    name: 'Toyota Fortuner 2.8 Legender 4WD',
    category: 'suv',
    categoryName: 'SUV 4WD',
    year: 2024,
    price: 2200,
    deposit: 10000,
    image: 'images/car-suv.svg',
    fuel: 'ดีเซล (Diesel B7)',
    transmission: 'Auto 6-Speed 4WD',
    seats: 7,
    engine: '2.8L GD Turbo Diesel 204 HP',
    features: ['Sigma4 4WD', '360° Camera', 'JBL Sound System', 'Power Backdoor', 'Roof Rails'],
    badge: 'แนะนำครอบครัว / ท่องเที่ยว 🏔️',
    badgeType: 'primary',
    rating: 4.98,
    trips: 489,
    available: true
  },
  {
    id: 'car-benz',
    type: 'car',
    name: 'Mercedes-Benz E220d Exclusive',
    category: 'luxury',
    categoryName: 'Luxury Executive',
    year: 2024,
    price: 4500,
    deposit: 20000,
    image: 'images/car-luxury.svg',
    fuel: 'ดีเซล (Euro 6 Diesel)',
    transmission: '9G-TRONIC Auto',
    seats: 5,
    engine: '2.0L Turbo Diesel 200 HP',
    features: ['Burmester 4D Audio', 'MBUX Superscreen', 'Air Suspension', 'Ambient Lighting 64c', 'Chauffeur Package'],
    badge: 'Luxury Class ✨',
    badgeType: 'purple',
    rating: 5.0,
    trips: 112,
    available: true
  },
  {
    id: 'car-byd',
    type: 'car',
    name: 'BYD Atto 3 Extended Range',
    category: 'ev',
    categoryName: 'Electric EV SUV',
    year: 2024,
    price: 1650,
    deposit: 8000,
    image: 'images/car-ev.svg',
    fuel: 'ไฟฟ้า 100% (Blade Battery)',
    transmission: 'Single Speed Auto',
    seats: 5,
    engine: 'Electric Motor 201 HP (480 km/charge)',
    features: ['CCS2 Fast Charging 80kW', 'V2L Power Bank', 'Rotating 15.6" Screen', 'Panoramic Sunroof', 'ADAS Level 2'],
    badge: 'EV รักษ์โลก ⚡ 0% มลพิษ',
    badgeType: 'teal',
    rating: 4.92,
    trips: 275,
    available: true
  },
  {
    id: 'car-hiace',
    type: 'car',
    name: 'Toyota HiAce Commuter VIP',
    category: 'van',
    categoryName: 'Van VIP 12-Seater',
    year: 2023,
    price: 2800,
    deposit: 12000,
    image: 'images/car-van.svg',
    fuel: 'ดีเซล (Diesel B7)',
    transmission: 'Manual 6-Speed',
    seats: 12,
    engine: '2.8L Turbo Diesel 177 HP',
    features: ['เบาะ VIP นวดไฟฟ้า', 'TV 24" & Karaoke', 'แอร์ไมโครบัสแยก 3 ตอน', 'USB ทุกที่นั่ง', 'ที่วางกระเป๋าขนาดใหญ่'],
    badge: 'หมู่คณะ / งานสัมมนา 👥',
    badgeType: 'info',
    rating: 4.88,
    trips: 195,
    available: true
  },

  // ── MOTORCYCLES ──
  {
    id: 'bike-pcx',
    type: 'bike',
    name: 'Honda PCX 160 ABS',
    category: 'scooter',
    categoryName: 'Scooter / City Ride',
    year: 2024,
    price: 380,
    deposit: 2000,
    image: 'images/bike-scooter.svg',
    fuel: 'เบนซิน 95 (Gasoline 95)',
    transmission: 'Auto (V-Matic)',
    seats: 2,
    engine: '157cc eSP+ 4-Valve',
    features: ['Honda Smart Key', 'ABS หน้า + HSTC', 'USB Type-C Charger', 'U-Box 30L', 'ฟรีหมวกกันน็อก 2 ใบ'],
    badge: 'รถจักรยานยนต์ยอดนิยม 🛵',
    badgeType: 'success',
    rating: 4.96,
    trips: 620,
    available: true
  },
  {
    id: 'bike-nmax',
    type: 'bike',
    name: 'Yamaha NMAX 155 VVA Connected',
    category: 'scooter',
    categoryName: 'Maxi Scooter',
    year: 2024,
    price: 420,
    deposit: 2000,
    image: 'images/bike-sport.svg',
    fuel: 'เบนซิน 95',
    transmission: 'Auto (V-Belt)',
    seats: 2,
    engine: '155cc Blue Core VVA',
    features: ['Y-Connect Smart App', 'Traction Control TCS', 'Dual-Channel ABS', 'Smart Key', 'ฟรีหมวกกันน็อก 2 ใบ'],
    badge: 'แรงคล่องตัว 💨',
    badgeType: 'primary',
    rating: 4.93,
    trips: 410,
    available: true
  },
  {
    id: 'bike-mt07',
    type: 'bike',
    name: 'Yamaha MT-07 Hyper Naked',
    category: 'bigbike',
    categoryName: 'BigBike Naked 689cc',
    year: 2024,
    price: 1390,
    deposit: 6000,
    image: 'images/bike-bigbike.svg',
    fuel: 'เบนซิน 95',
    transmission: 'Manual 6-Speed',
    seats: 2,
    engine: '689cc CP2 2-Cylinder 73.4 HP',
    features: ['Dual 298mm Front Disc ABS', 'TFT Full Color Display', 'Akrapovic Exhaust Option', 'Crash Protector', 'ฟรีหมวก Full-face'],
    badge: 'Hyper Naked แรงบิดจัดจ้าน ⚡',
    badgeType: 'warning',
    rating: 4.97,
    trips: 184,
    available: true
  },
  {
    id: 'bike-ninja',
    type: 'bike',
    name: 'Kawasaki Ninja 400 ABS',
    category: 'sport',
    categoryName: 'Sportbike 400cc',
    year: 2024,
    price: 1150,
    deposit: 5000,
    image: 'images/bike-ninja.svg',
    fuel: 'เบนซิน 95',
    transmission: 'Manual 6-Speed with Assist & Slipper Clutch',
    seats: 2,
    engine: '399cc Parallel Twin 45 HP',
    features: ['Assist & Slipper Clutch', 'Trellis Frame', 'Twin LED Headlamps', 'Gear Indicator', 'ฟรีหมวก Full-face'],
    badge: 'Sport Track Ready 🏁',
    badgeType: 'success',
    rating: 4.94,
    trips: 162,
    available: true
  },
  {
    id: 'bike-cb500x',
    type: 'bike',
    name: 'Honda CB500X Adventure Touring',
    category: 'adventure',
    categoryName: 'Adventure Touring 500cc',
    year: 2024,
    price: 1290,
    deposit: 5000,
    image: 'images/bike-adv.svg',
    fuel: 'เบนซิน 95',
    transmission: 'Manual 6-Speed',
    seats: 2,
    engine: '471cc Parallel Twin 47 HP',
    features: ['กระเป๋าข้าง Panniers 2 ฝั่ง', 'ชิลด์หน้าปรับสูง', 'Showa 41mm SFF-BP Upside Down', 'Crash Bar กันล้ม', 'USB-A Charger'],
    badge: 'พร้อมทัวร์ริ่งทั่วไทย 🏕️',
    badgeType: 'purple',
    rating: 4.99,
    trips: 208,
    available: true
  },
  {
    id: 'bike-ev',
    type: 'bike',
    name: 'Deco Super Ace EV Scooter',
    category: 'ev',
    categoryName: 'Electric EV Scooter',
    year: 2024,
    price: 350,
    deposit: 1500,
    image: 'images/bike-ev.svg',
    fuel: 'ไฟฟ้า 100% (Lithium-ion Swap Battery)',
    transmission: 'Auto Electric Hub Motor',
    seats: 2,
    engine: '2000W Motor (Max 80 km/h, 100 km/charge)',
    features: ['แบตเตอรี่ถอดสลับได้ทันที', 'Smart Key & Alarm', 'CBS Brake System', 'Digital LCD Screen', 'ชาร์จไฟบ้าน 3 ชม.'],
    badge: 'EV มอเตอร์ไซค์รักษ์โลก ⚡',
    badgeType: 'teal',
    rating: 4.91,
    trips: 310,
    available: true
  }
];

/* ── Toast Notifications ── */
const Toast = {
  container: null,
  init() {
    this.container = document.getElementById('toastContainer');
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toastContainer';
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(message, type = 'info', duration = 3500) {
    this.init();
    const icons = { info:'ℹ️', success:'✅', warning:'⚠️', danger:'❌' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span style="font-size:1.25rem">${icons[type] || 'ℹ️'}</span>
      <div style="flex:1">
        <div style="font-weight:700;font-size:.875rem;margin-bottom:.1rem">${type.charAt(0).toUpperCase()+type.slice(1)}</div>
        <div style="font-size:.82rem;color:var(--text-secondary)">${message}</div>
      </div>
      <button onclick="this.closest('.toast').remove()" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:1.1rem;padding:0 .2rem">✕</button>
    `;
    this.container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all .3s ease';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }
};

/* ── Modal Management ── */
const Modal = {
  open(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  },
  close(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.remove('open');
      document.body.style.overflow = '';
    }
  }
};
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

/* ── Local Storage & State Management ── */
const storage = {
  get: key => {
    try {
      const data = localStorage.getItem('ct_' + key);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },
  set: (key, val) => {
    try {
      localStorage.setItem('ct_' + key, JSON.stringify(val));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  },
  del: key => {
    try {
      localStorage.removeItem('ct_' + key);
    } catch (e) {}
  }
};

/* ── Default Active Booking Helper ── */
function getActiveBooking() {
  const b = storage.get('booking');
  if (b && b.vehicleId) {
    const v = VEHICLES.find(x => x.id === b.vehicleId) || VEHICLES[2]; // Default Fortuner
    return { ...b, vehicle: v };
  }
  // Fallback defaults
  const defaultVehicle = VEHICLES[2]; // Toyota Fortuner
  const defaultBooking = {
    vehicleId: defaultVehicle.id,
    vehicle: defaultVehicle,
    pickupBranch: 'สนามบินสุวรรณภูมิ',
    returnBranch: 'สนามบินสุวรรณภูมิ',
    pickupDate: '2026-09-04',
    pickupTime: '09:00',
    returnDate: '2026-09-07',
    returnTime: '12:00',
    rentalDays: 3,
    addons: {
      cdw: true,
      gps: false,
      childSeat: false,
      driver: false,
      fuel: false,
      helmet: true
    },
    promoCode: '',
    discount: 0,
    renter: {
      firstName: 'สมชาย',
      lastName: 'วิภาตะพันธ์',
      email: 'somchai@email.com',
      phone: '081-234-5678',
      idCard: '1-1002-12345-67-8',
      driverLicense: 'DL-9988472',
      address: '123/45 ถนนสุขุมวิท 71 แขวงพระโขนงเหนือ เขตวัฒนา กรุงเทพฯ 10110'
    },
    paymentMethod: 'promptpay',
    status: 'pending_kyc',
    bookingId: 'CT-' + Math.floor(100000 + Math.random() * 900000)
  };
  storage.set('booking', defaultBooking);
  return defaultBooking;
}

function selectVehicleAndBook(vehicleId) {
  const vehicle = VEHICLES.find(v => v.id === vehicleId) || VEHICLES[0];
  const booking = getActiveBooking();
  booking.vehicleId = vehicle.id;
  booking.vehicle = vehicle;
  storage.set('booking', booking);
  Toast.show(`เลือก ${vehicle.name} แล้ว — กำลังไปหน้าจอง`, 'success', 1500);
  setTimeout(() => {
    window.location.href = 'booking.html';
  }, 600);
}

/* ── Tabs Helper ── */
function initTabs(container) {
  if (!container) return;
  const tabs = container.querySelectorAll('.tab');
  const panels = container.querySelectorAll('.tab-panel');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      const targetId = tab.dataset.tab;
      const target = container.querySelector('#' + targetId) || document.getElementById(targetId);
      if (target) target.classList.add('active');
    });
  });
}

/* ── Dropdowns Helper ── */
function initDropdowns() {
  document.querySelectorAll('.dropdown').forEach(dd => {
    const trigger = dd.querySelector('[data-dropdown-trigger]');
    if (trigger) {
      trigger.addEventListener('click', e => {
        e.stopPropagation();
        dd.classList.toggle('open');
      });
    }
  });
  document.addEventListener('click', () => {
    document.querySelectorAll('.dropdown.open').forEach(dd => dd.classList.remove('open'));
  });
}

/* ── Navbar Scroll & Mobile Toggle ── */
function initNavbar() {
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 40);
    });
  }
  const toggleBtn = document.getElementById('mobileNavToggle');
  const navLinks = document.querySelector('.nav-links');
  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener('click', () => {
      navLinks.classList.toggle('mobile-open');
    });
  }
}

/* ── Scroll Animations ── */
function initScrollAnimations() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('[data-animate]').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity .6s ease, transform .6s ease';
    observer.observe(el);
  });
}

/* ── Number Counter Animation ── */
function animateCounter(el, target, duration = 1500) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start += step;
    if (start >= target) {
      start = target;
      clearInterval(timer);
    }
    el.textContent = Math.floor(start).toLocaleString();
  }, 16);
}

/* ── File Upload Drag & Drop with Preview ── */
function initUploadZones() {
  document.querySelectorAll('.upload-zone').forEach(zone => {
    zone.addEventListener('dragover', e => {
      e.preventDefault();
      zone.classList.add('dragover');
    });
    zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
    zone.addEventListener('drop', e => {
      e.preventDefault();
      zone.classList.remove('dragover');
      if (e.dataTransfer.files && e.dataTransfer.files.length) {
        handleFileUpload(zone, e.dataTransfer.files[0]);
      }
    });
    const input = zone.querySelector('input[type=file]');
    if (input) {
      zone.addEventListener('click', () => input.click());
      input.addEventListener('change', () => {
        if (input.files && input.files.length) {
          handleFileUpload(zone, input.files[0]);
        }
      });
    }
  });
}

function handleFileUpload(zone, file) {
  const reader = new FileReader();
  reader.onload = e => {
    if (file.type.startsWith('image/')) {
      zone.innerHTML = `
        <img src="${e.target.result}" style="max-height:160px;border-radius:8px;margin:auto;object-fit:cover;box-shadow:0 4px 12px rgba(0,0,0,0.3)">
        <p style="margin-top:.75rem;font-size:.85rem;font-weight:600;color:var(--secondary)">✅ ${file.name}</p>
        <span style="font-size:.75rem;color:var(--text-muted)">คลิกเพื่อเปลี่ยนรูป</span>
      `;
    } else {
      zone.innerHTML = `
        <div style="font-size:2.5rem">📄</div>
        <p style="font-weight:600;margin:.5rem 0">${file.name}</p>
        <p style="font-size:.85rem;color:var(--secondary)">✅ อัปโหลดเอกสารสำเร็จ</p>
      `;
    }
    Toast.show(`อัปโหลด ${file.name} สำเร็จ`, 'success', 2000);
  };
  reader.readAsDataURL(file);
}

/* ── Signature Pad with Touch & Mouse Support ── */
function initSignaturePad(canvasId, labelId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;
  const ctx = canvas.getContext('2d');
  const label = document.getElementById(labelId);
  let drawing = false;
  let hasSignature = false;
  const history = [];

  function resize() {
    const ratio = Math.max(window.devicePixelRatio || 1, 1);
    const rect = canvas.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      canvas.width = rect.width * ratio;
      canvas.height = rect.height * ratio;
      ctx.scale(ratio, ratio);
      ctx.strokeStyle = '#60a5fa';
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }
  }
  resize();
  window.addEventListener('resize', resize);

  const getPos = e => {
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches ? e.touches[0] : e;
    return {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top
    };
  };

  const start = e => {
    drawing = true;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    if (!hasSignature) {
      hasSignature = true;
      if (label) label.classList.add('hidden');
    }
    if (e.cancelable && e.type.startsWith('touch')) e.preventDefault();
  };

  const draw = e => {
    if (!drawing) return;
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    if (e.cancelable && e.type.startsWith('touch')) e.preventDefault();
  };

  const stop = () => {
    if (drawing) {
      drawing = false;
      history.push(canvas.toDataURL());
    }
  };

  canvas.addEventListener('mousedown', start);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('mouseup', stop);
  canvas.addEventListener('mouseleave', stop);
  canvas.addEventListener('touchstart', start, { passive: false });
  canvas.addEventListener('touchmove', draw, { passive: false });
  canvas.addEventListener('touchend', stop);

  return {
    clear() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      hasSignature = false;
      history.length = 0;
      if (label) label.classList.remove('hidden');
    },
    undo() {
      if (history.length > 1) {
        history.pop();
        const img = new Image();
        img.onload = () => {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width / (window.devicePixelRatio || 1), canvas.height / (window.devicePixelRatio || 1));
        };
        img.src = history[history.length - 1];
      } else {
        this.clear();
      }
    },
    isEmpty() { return !hasSignature; },
    toDataURL() { return canvas.toDataURL('image/png'); }
  };
}

/* ── Vehicle Inspection Canvas (Damage Marker) ── */
function initInspectionCanvas(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;
  const ctx = canvas.getContext('2d');
  const marks = [];
  let activeTool = 'scratch';
  const colors = { scratch: '#ef4444', dent: '#f59e0b', chip: '#a855f7', ok: '#22c55e' };

  canvas.addEventListener('click', e => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    marks.push({ x, y, type: activeTool, time: new Date().toLocaleTimeString('th-TH') });
    redraw();
    Toast.show(`บันทึกจุดตรวจ: ${activeTool.toUpperCase()}`, 'info', 1200);
  });

  function redraw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    marks.forEach((m, idx) => {
      ctx.beginPath();
      ctx.arc(m.x, m.y, 14, 0, Math.PI * 2);
      ctx.fillStyle = (colors[m.type] || '#ef4444') + '55';
      ctx.fill();
      ctx.strokeStyle = colors[m.type] || '#ef4444';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(m.x, m.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      ctx.font = 'bold 10px Inter, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(`#${idx + 1}`, m.x, m.y - 18);
    });
  }

  return {
    setTool(t) { activeTool = t; },
    clear() { marks.length = 0; ctx.clearRect(0, 0, canvas.width, canvas.height); },
    undo() { marks.pop(); redraw(); },
    getMarks() { return marks; }
  };
}

/* ── Camera Helper for e-KYC ── */
const CameraHelper = {
  stream: null,
  async start(videoElId) {
    const video = document.getElementById(videoElId);
    if (!video) return false;
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        this.stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
          audio: false
        });
        video.srcObject = this.stream;
        video.style.display = 'block';
        video.play();
        return true;
      }
    } catch (err) {
      console.warn('Camera access error or permission denied:', err);
    }
    return false;
  },
  stop() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  },
  capture(videoElId) {
    const video = document.getElementById(videoElId);
    if (!video) return null;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 480;
    canvas.height = video.videoHeight || 360;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg');
  }
};

/* ── Formatting Helpers ── */
const fmt = {
  currency: (n, currency = 'THB') => new Intl.NumberFormat('th-TH', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n),
  number: n => new Intl.NumberFormat('th-TH').format(n),
  date: d => new Date(d).toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric' }),
  time: d => new Date(d).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })
};

/* ── Global GPS Fleet Simulator for Live Tracking ── */
function createFleetSimulator() {
  // Bangkok base coords
  const fleet = [
    { id: 'CT-01', name: 'Toyota Fortuner (กข-1234)', lat: 13.7462, lng: 100.5347, speed: 64, heading: 45, status: 'moving', vehicle: VEHICLES[2] },
    { id: 'CT-02', name: 'Honda PCX 160 (1กข-5678)', lat: 13.7298, lng: 100.5698, speed: 42, heading: 120, status: 'moving', vehicle: VEHICLES[6] },
    { id: 'CT-03', name: 'BYD Atto 3 (3ขค-9988)', lat: 13.6900, lng: 100.7501, speed: 0, heading: 0, status: 'parked', vehicle: VEHICLES[4] },
    { id: 'CT-04', name: 'Yamaha MT-07 (5กจ-4411)', lat: 13.7563, lng: 100.5018, speed: 78, heading: 270, status: 'moving', vehicle: VEHICLES[8] }
  ];

  return {
    getFleet() { return fleet; },
    tick() {
      fleet.forEach(item => {
        if (item.status === 'moving') {
          const rad = (item.heading * Math.PI) / 180;
          item.lat += Math.cos(rad) * 0.0003;
          item.lng += Math.sin(rad) * 0.0003;
          item.heading = (item.heading + (Math.random() - 0.5) * 15) % 360;
          item.speed = Math.max(20, Math.min(110, item.speed + (Math.random() - 0.5) * 8));
        }
      });
      return fleet;
    }
  };
}

/* ── Document Ready Global Handlers ── */
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initScrollAnimations();
  initDropdowns();
  initUploadZones();
  document.querySelectorAll('[data-tabs]').forEach(initTabs);

  // Counter animations
  document.querySelectorAll('[data-counter]').forEach(el => {
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        animateCounter(el, parseInt(el.dataset.counter, 10));
        observer.unobserve(el);
      }
    });
    observer.observe(el);
  });

  // Modal triggers
  document.querySelectorAll('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => Modal.open(btn.dataset.modalOpen));
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => Modal.close(btn.dataset.modalClose));
  });

  // Check login state and update user badge in navbar if present
  const user = storage.get('user');
  const userSlot = document.getElementById('navUserSlot');
  if (user && userSlot) {
    userSlot.innerHTML = `
      <div style="display:flex;align-items:center;gap:.6rem">
        <span style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem;color:#fff">${user.name ? user.name[0] : 'U'}</span>
        <span style="font-size:.875rem;font-weight:600">${user.name || 'คุณสมชาย'}</span>
        <button onclick="logoutUser()" class="btn btn-ghost btn-sm" style="padding:.2rem .5rem;font-size:.75rem">ออก</button>
      </div>
    `;
  }
});

function loginUser(name = 'สมชาย วิภาตะพันธ์', email = 'somchai@email.com') {
  storage.set('user', { name, email, loggedIn: true, time: new Date().toISOString() });
  Toast.show(`ยินดีต้อนรับคุณ ${name}`, 'success', 2000);
  Modal.close('loginModal');
  setTimeout(() => window.location.reload(), 600);
}

function logoutUser() {
  storage.del('user');
  Toast.show('ออกจากระบบแล้ว', 'info', 1500);
  setTimeout(() => window.location.reload(), 500);
}
