$git = "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\TeamFoundation\Team Explorer\Git\cmd\git.exe"

Write-Host "1. Adding files..." -ForegroundColor Cyan
& $git add .

Write-Host "2. Committing..." -ForegroundColor Cyan
& $git commit -m "feat: complete CarTrack Pro system with cars & motorcycles preview"

Write-Host "3. Setting remote..." -ForegroundColor Cyan
& $git remote remove origin 2>$null
& $git remote add origin https://github.com/w4772851-design/wrararat.git

Write-Host "4. Pushing to GitHub (main)..." -ForegroundColor Green
& $git push -u origin main

Write-Host "Done!" -ForegroundColor Green
