@echo off
chcp 65001 >nul
echo ====================================================
echo  CarTrack Pro - Pushing Code to GitHub
echo ====================================================
echo.

set "GIT_EXE=C:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\TeamFoundation\Team Explorer\Git\cmd\git.exe"

echo 1. Adding all files...
"%GIT_EXE%" add .

echo 2. Committing changes...
"%GIT_EXE%" commit -m "feat: complete CarTrack Pro system with cars & motorcycles preview"

echo 3. Setting remote repository...
"%GIT_EXE%" remote remove origin 2>nul
"%GIT_EXE%" remote add origin https://github.com/w4772851-design/wrararat.git

echo 4. Pushing to GitHub (main branch)...
"%GIT_EXE%" push -u origin main

echo.
echo ====================================================
echo  Finished!
echo ====================================================
pause
